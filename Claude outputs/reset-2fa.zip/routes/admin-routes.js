const express = require('express');
const router = express.Router();
const { pool, auditLog, bcrypt, requireAuth } = require('../auth');
const { USERS, VALID_ROLES } = require('../constants');

const MIN_PASSWORD_LENGTH = 8;

function validateRole(role) {
  return VALID_ROLES.has(role);
}

function sanitizeError(e, res) {
  console.error('Admin route error:', e.message);
  res.status(500).json({ ok: false, error: 'Внутренняя ошибка сервера' });
}

// GET /admin/tg-links
router.get('/tg-links', requireAuth(['admin']), async (req, res) => {
  try {
    const links = await pool.query(
      'SELECT bitrix_user_id, telegram_chat_id, linked_at FROM ticketsmodule_telegram_links'
    );
    const linkMap = {};
    for (const row of links.rows) linkMap[row.bitrix_user_id] = row;

    const users = Object.entries(USERS)
      .filter(([id]) => Number(id) > 10)
      .map(([id, name]) => ({
        id: Number(id), name,
        linked: !!linkMap[id],
        linkedAt: linkMap[id]?.linked_at || null,
      }))
      .sort((a, b) => a.name.localeCompare(b.name, 'ru'));

    res.json({ ok: true, users });
  } catch(e) { sanitizeError(e, res); }
});

// GET /admin/employee-options — все сотрудники для привязки учётки к Bitrix.
// В отличие от /tg-links (там фильтр id>10 для служебных учёток) здесь показываем
// ВСЕХ реальных людей, включая ID ≤ 10 (напр. Куаныш Есенов = 4), исключая только
// настоящие служебные аккаунты.
const SERVICE_ACCOUNTS = new Set(['Администратор', 'Power BI']);
router.get('/employee-options', requireAuth(['admin']), async (req, res) => {
  try {
    const users = Object.entries(USERS)
      .map(([id, name]) => ({ id: Number(id), name }))
      .filter(u => u.name && !SERVICE_ACCOUNTS.has(u.name))
      .sort((a, b) => a.name.localeCompare(b.name, 'ru'));
    res.json({ ok: true, users });
  } catch (e) { sanitizeError(e, res); }
});

// GET /admin/users
router.get('/users', requireAuth(['admin']), async (req, res) => {
  try {
    const r = await pool.query(
      'SELECT id,username,display_name,role,totp_enabled,active,engineer_name,mail_mailbox,kp_categories,bitrix_user_id,created_at FROM ticketsmodule_users'
    );
    // Всегда по алфавиту (кириллица корректно — через localeCompare 'ru').
    r.rows.sort((a, b) => String(a.display_name || '').localeCompare(String(b.display_name || ''), 'ru', { sensitivity: 'base' }));
    res.json({ ok: true, users: r.rows });
  } catch(e) { sanitizeError(e, res); }
});

// POST /admin/users
router.post('/users', requireAuth(['admin']), async (req, res) => {
  try {
    const { username, displayName, password, role, engineerName, mailMailbox, kpCategories, bitrixUserId } = req.body;
    const bitrixId = (bitrixUserId === '' || bitrixUserId == null) ? null : parseInt(bitrixUserId, 10) || null;

    if (!username || !password || !role) {
      return res.status(400).json({ ok: false, error: 'Заполните все обязательные поля' });
    }
    if (typeof username !== 'string' || username.trim().length < 3) {
      return res.status(400).json({ ok: false, error: 'Логин минимум 3 символа' });
    }
    if (typeof password !== 'string' || password.length < MIN_PASSWORD_LENGTH) {
      return res.status(400).json({ ok: false, error: `Пароль минимум ${MIN_PASSWORD_LENGTH} символов` });
    }
    if (!validateRole(role)) {
      return res.status(400).json({ ok: false, error: 'Недопустимая роль' });
    }

    const hash = await bcrypt.hash(password, 12);
    const r = await pool.query(
      `INSERT INTO ticketsmodule_users (username, display_name, password_hash, role, engineer_name, mail_mailbox, kp_categories, bitrix_user_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [username.trim().toLowerCase(), (displayName || username).trim(), hash, role, engineerName || null, mailMailbox || null, JSON.stringify(kpCategories || []), bitrixId]
    );
    await auditLog(req.user.id, req.user.username, 'USER_CREATED', null,
      { newUser: username, role }, req.ip, req.headers['user-agent']);
    res.json({ ok: true, userId: r.rows[0].id });
  } catch(e) {
    if (e.code === '23505') return res.status(400).json({ ok: false, error: 'Пользователь с таким логином уже существует' });
    sanitizeError(e, res);
  }
});

// PUT /admin/users/:id
router.put('/users/:id', requireAuth(['admin']), async (req, res) => {
  try {
    const { displayName, role, active, engineerName, mailMailbox, kpCategories, password, username, bitrixUserId } = req.body;
    const id = parseInt(req.params.id);
    if (!id) return res.status(400).json({ ok: false, error: 'Неверный ID' });
    const bitrixId = (bitrixUserId === '' || bitrixUserId == null) ? null : parseInt(bitrixUserId, 10) || null;

    if (role && !validateRole(role)) {
      return res.status(400).json({ ok: false, error: 'Недопустимая роль' });
    }
    // Prevent removing last admin
    if (role && role !== 'admin') {
      const adminCount = await pool.query(
        "SELECT COUNT(*) FROM ticketsmodule_users WHERE role='admin' AND active=true AND id!=$1", [id]
      );
      if (parseInt(adminCount.rows[0].count) === 0) {
        return res.status(400).json({ ok: false, error: 'Нельзя убрать роль admin у последнего администратора' });
      }
    }
    if (username?.trim()) {
      const newUsername = username.trim();
      const dupe = await pool.query('SELECT 1 FROM ticketsmodule_users WHERE username=$1 AND id!=$2', [newUsername, id]);
      if (dupe.rows.length) return res.status(400).json({ ok: false, error: 'Такой логин уже занят' });
      await pool.query('UPDATE ticketsmodule_users SET username=$1, updated_at=NOW() WHERE id=$2', [newUsername, id]);
    }
    if (password?.trim()) {
      if (password.length < MIN_PASSWORD_LENGTH) {
        return res.status(400).json({ ok: false, error: `Пароль минимум ${MIN_PASSWORD_LENGTH} символов` });
      }
      const hash = await bcrypt.hash(password, 12);
      await pool.query('UPDATE ticketsmodule_users SET password_hash=$1, updated_at=NOW() WHERE id=$2', [hash, id]);
    }
    await pool.query(
      `UPDATE ticketsmodule_users SET display_name=$1, role=$2, active=$3, engineer_name=$4, mail_mailbox=$5, kp_categories=$6, bitrix_user_id=$7, updated_at=NOW() WHERE id=$8`,
      [(displayName||'').trim(), role, Boolean(active), engineerName||null, mailMailbox||null, JSON.stringify(kpCategories || []), bitrixId, id]
    );
    await auditLog(req.user.id, req.user.username, 'USER_UPDATED', null,
      { targetId: id, role, active, usernameChanged: !!username?.trim() }, req.ip, req.headers['user-agent']);
    res.json({ ok: true });
  } catch(e) { sanitizeError(e, res); }
});

// POST /admin/users/:id/reset-2fa — сбросить 2FA сотруднику (потерял аутентификатор).
// После сброса при следующем входе он пройдёт обязательную настройку 2FA заново
// (новый QR). Только админ.
router.post('/users/:id/reset-2fa', requireAuth(['admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (!id) return res.status(400).json({ ok: false, error: 'Неверный ID' });
    const r = await pool.query('UPDATE ticketsmodule_users SET totp_secret=NULL, totp_enabled=false, updated_at=NOW() WHERE id=$1 RETURNING username', [id]);
    if (!r.rows.length) return res.status(404).json({ ok: false, error: 'Пользователь не найден' });
    await auditLog(req.user.id, req.user.username, 'USER_2FA_RESET', null, { targetId: id }, req.ip, req.headers['user-agent']);
    res.json({ ok: true, username: r.rows[0].username });
  } catch (e) { sanitizeError(e, res); }
});

// DELETE /admin/users/:id (soft delete)
router.delete('/users/:id', requireAuth(['admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (id === req.user.id) return res.status(400).json({ ok: false, error: 'Нельзя деактивировать себя' });
    await pool.query('UPDATE ticketsmodule_users SET active=false, updated_at=NOW() WHERE id=$1', [id]);
    await auditLog(req.user.id, req.user.username, 'USER_DEACTIVATED', null, { targetId: id }, req.ip, req.headers['user-agent']);
    res.json({ ok: true });
  } catch(e) { sanitizeError(e, res); }
});

// DELETE /admin/users/:id/permanent — безвозвратное удаление учётки.
// Нельзя удалить себя и последнего активного администратора. Журнал действий
// сохраняется (user_id обнулится по ON DELETE SET NULL, имя останется в записях).
router.delete('/users/:id/permanent', requireAuth(['admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (!id) return res.status(400).json({ ok: false, error: 'Неверный ID' });
    if (id === req.user.id) return res.status(400).json({ ok: false, error: 'Нельзя удалить себя' });
    const u = await pool.query('SELECT username, display_name, role FROM ticketsmodule_users WHERE id=$1', [id]);
    if (!u.rows.length) return res.status(404).json({ ok: false, error: 'Пользователь не найден' });
    if (u.rows[0].role === 'admin') {
      const admins = await pool.query("SELECT COUNT(*) FROM ticketsmodule_users WHERE role='admin' AND active=true AND id!=$1", [id]);
      if (parseInt(admins.rows[0].count) === 0) {
        return res.status(400).json({ ok: false, error: 'Нельзя удалить последнего администратора' });
      }
    }
    await pool.query('DELETE FROM ticketsmodule_users WHERE id=$1', [id]);
    await auditLog(req.user.id, req.user.username, 'USER_DELETED', null,
      { targetId: id, username: u.rows[0].username, name: u.rows[0].display_name }, req.ip, req.headers['user-agent']);
    res.json({ ok: true });
  } catch(e) { sanitizeError(e, res); }
});

// POST /admin/import-bitrix-users — массовое создание учёток по сотрудникам Bitrix.
// Логин = корпоративная почта из Bitrix, пароль у всех стартовый «123qwerty»
// (сотрудники сменят сами), роль по умолчанию — viewer (Просмотр), имя как в
// Bitrix, сразу проставляется bitrix_user_id (для уведомлений). Категорию КП и
// почтовый ящик НЕ трогаем. Идемпотентно: существующие учётки (по логину) не
// изменяются — можно запускать повторно при найме новых.
router.post('/import-bitrix-users', requireAuth(['admin']), async (req, res) => {
  try {
    const { fetchAllActiveUsers } = require('./planner-routes');
    const users = await fetchAllActiveUsers();
    const SERVICE = new Set(['Администратор', 'Power BI', 'Администратор Портала']);
    const hash = await bcrypt.hash('123qwerty', 12); // один хэш на всех — общий стартовый пароль
    let added = 0, skippedExisting = 0, skippedNoEmail = 0;
    const noEmail = [];
    for (const u of users) {
      const id = parseInt(u.ID, 10);
      const name = `${u.NAME || ''} ${u.LAST_NAME || ''}`.trim();
      if (!id || !name || SERVICE.has(name)) continue;
      const email = String(u.EMAIL || '').trim().toLowerCase();
      if (!email) { skippedNoEmail++; noEmail.push({ id, name }); continue; }
      const r = await pool.query(
        `INSERT INTO ticketsmodule_users (username, display_name, password_hash, role, bitrix_user_id, active)
         VALUES ($1,$2,$3,'viewer',$4,true)
         ON CONFLICT (username) DO NOTHING RETURNING id`,
        [email, name, hash, id]
      );
      if (r.rows.length) added++; else skippedExisting++;
    }
    await auditLog(req.user.id, req.user.username, 'BULK_IMPORT_BITRIX_USERS', null,
      { added, skippedExisting, skippedNoEmail }, req.ip, req.headers['user-agent']);
    res.json({ ok: true, added, skippedExisting, skippedNoEmail, noEmail });
  } catch (e) { sanitizeError(e, res); }
});

// GET /admin/logs
router.get('/logs', requireAuth(['admin']), async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 50, 200);
    const offset = Math.max(parseInt(req.query.offset) || 0, 0);
    const { userId, action, ticketId, search } = req.query;

    const conditions = [];
    const params = [];
    if (userId && /^\d+$/.test(userId)) { params.push(parseInt(userId)); conditions.push(`l.user_id=$${params.length}`); }
    if (action && /^[A-Z_]+$/.test(action)) { params.push(action); conditions.push(`l.action=$${params.length}`); }
    if (ticketId && /^\d+$/.test(ticketId)) { params.push(parseInt(ticketId)); conditions.push(`l.ticket_id=$${params.length}`); }
    if (search && search.length <= 100) { params.push(`%${search.replace(/[%_]/g, '\\$&')}%`); conditions.push(`(l.username ILIKE $${params.length} OR l.action ILIKE $${params.length})`); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    params.push(limit, offset);

    const r = await pool.query(
      `SELECT l.id, l.username, l.action, l.ticket_id, l.details, l.ip, l.created_at, u.display_name
       FROM ticketsmodule_audit_logs l
       LEFT JOIN ticketsmodule_users u ON l.user_id=u.id
       ${where} ORDER BY l.created_at DESC LIMIT $${params.length-1} OFFSET $${params.length}`,
      params
    );
    const cnt = await pool.query(`SELECT COUNT(*) FROM ticketsmodule_audit_logs l ${where}`, params.slice(0, -2));
    res.json({ ok: true, logs: r.rows, total: parseInt(cnt.rows[0].count) });
  } catch(e) { sanitizeError(e, res); }
});

// GET /admin/notification-log — who was notified about which planner event, when, and whether it actually went through
router.get('/notification-log', requireAuth(['admin']), async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 50, 200);
    const offset = Math.max(parseInt(req.query.offset) || 0, 0);
    const { itemId, channel, success } = req.query;

    const conditions = [];
    const params = [];
    if (itemId && /^\d+$/.test(itemId)) { params.push(parseInt(itemId)); conditions.push(`bitrix_item_id=$${params.length}`); }
    if (channel && ['telegram','email'].includes(channel)) { params.push(channel); conditions.push(`channel=$${params.length}`); }
    if (success === 'true' || success === 'false') { params.push(success === 'true'); conditions.push(`success=$${params.length}`); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    params.push(limit, offset);

    const r = await pool.query(
      `SELECT id, sent_at, bitrix_item_id, reason, channel, recipient_bitrix_id, recipient_label, success, error
       FROM ticketsmodule_notification_log
       ${where} ORDER BY sent_at DESC LIMIT $${params.length-1} OFFSET $${params.length}`,
      params
    );
    const cnt = await pool.query(`SELECT COUNT(*) FROM ticketsmodule_notification_log ${where}`, params.slice(0, -2));
    res.json({ ok: true, logs: r.rows, total: parseInt(cnt.rows[0].count) });
  } catch(e) { sanitizeError(e, res); }
});

// ── ЦУП module access (which portal modules each Bitrix employee can see) ──
// Keep this list in sync with MODULES in public/portal.html and cup-admin.html.
const MODULE_CODES = ['PLN', 'SVC', 'EQP', 'LIC', 'REL', 'MAIL', 'KP', 'BONUS', 'STATS', 'CONTR', 'SALE', 'NKT', 'PROJ', 'LOG', 'OPS', 'PROC', 'CAM', 'ADM'];

// GET /admin/bitrix-employees — every active Bitrix employee + their current module access
router.get('/bitrix-employees', requireAuth(['admin']), async (req, res) => {
  try {
    const { fetchAllActiveUsers } = require('./planner-routes');
    const users = await fetchAllActiveUsers();
    const { rows } = await pool.query('SELECT bitrix_user_id, modules FROM ticketsmodule_module_access');
    const accessById = new Map(rows.map(r => [r.bitrix_user_id, r.modules]));
    const SERVICE_ACCOUNT_NAMES = new Set(['Администратор', 'Power BI']);

    const employees = users
      .map(u => ({ id: parseInt(u.ID, 10), name: `${u.NAME || ''} ${u.LAST_NAME || ''}`.trim() }))
      .filter(e => e.name && !SERVICE_ACCOUNT_NAMES.has(e.name))
      .map(e => ({ ...e, modules: accessById.get(e.id) || [] }))
      .sort((a, b) => a.name.localeCompare(b.name, 'ru'));

    res.json({ ok: true, employees, moduleCodes: MODULE_CODES });
  } catch (e) { sanitizeError(e, res); }
});

// PUT /admin/module-access/:bitrixUserId — save one employee's allowed modules
router.put('/module-access/:bitrixUserId', requireAuth(['admin']), async (req, res) => {
  try {
    const bitrixUserId = parseInt(req.params.bitrixUserId, 10);
    const modules = Array.isArray(req.body.modules) ? req.body.modules.filter(m => MODULE_CODES.includes(m)) : [];
    if (!bitrixUserId) return res.status(400).json({ ok: false, error: 'Неверный ID' });
    await pool.query(
      `INSERT INTO ticketsmodule_module_access (bitrix_user_id, modules, updated_at) VALUES ($1,$2,NOW())
       ON CONFLICT (bitrix_user_id) DO UPDATE SET modules=$2, updated_at=NOW()`,
      [bitrixUserId, JSON.stringify(modules)]
    );
    await auditLog(req.user.id, req.user.username, 'MODULE_ACCESS_UPDATED', null, { bitrixUserId, modules }, req.ip, req.headers['user-agent']);
    res.json({ ok: true });
  } catch (e) { sanitizeError(e, res); }
});

// GET /admin/discover-fields — временная разведка полей сделки для настройки
// модуля «Проекты / Комплексные сделки». Дёргает поля рабочим серверным вебхуком
// и показывает совпадения по ключевым словам + значения «Тип КП/Договора».
// Только админ. Можно удалить после настройки.
router.get('/discover-fields', requireAuth(['admin']), async (req, res) => {
  try {
    const { b24 } = require('../bitrix');
    const { result } = await b24('crm.deal.fields', {});
    const fields = result || {};
    const RE = /комплексн|родительск|complex|тип\s*(кп|договор)|dogovor|групп.*компан|холдинг|конечн|end.?user|parent|основн.*сделк/i;
    const matches = [];
    let dogovorType = null;
    for (const [code, f] of Object.entries(fields)) {
      const label = f.formLabel || f.title || f.listLabel || '';
      const items = Array.isArray(f.items) ? f.items.map(i => ({ id: i.ID, value: i.VALUE })) : null;
      if (RE.test(label) || RE.test(code)) {
        matches.push({ code, type: (f.type || '') + (f.isMultiple ? '[]' : ''), label, items });
      }
      if (code === 'UF_CRM_DOGOVOR_TYPE') dogovorType = items;
    }
    res.set('Cache-Control', 'no-store');
    res.json({ ok: true, total: Object.keys(fields).length, dogovorType, matches });
  } catch (e) {
    console.error('discover-fields error:', e.message);
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
