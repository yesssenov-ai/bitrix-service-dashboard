// Модуль «Рассылки»: массовые письма клиентам по сфере деятельности (Bitrix
// INDUSTRY). Аудитория (компании + их e-mail из компаний и контактов) кэшируется
// в БД, письма шлём через Resend с отдельного поддомена. Отписка + стоп-лист.
const fetch = require('node-fetch');
const crypto = require('crypto');
const { b24 } = require('./bitrix');
const { pool } = require('./auth');

const RESEND_KEY = process.env.RESEND_API_KEY;
const JWT_SECRET = process.env.JWT_SECRET || 'x';
const APP_BASE = process.env.APP_BASE_URL || 'https://nms.prolabsupport.kz';
// Отдельный поддомен для рассылок (репутация не бьёт по основной почте).
// Пропиши CAMPAIGN_FROM="ProLabSupport <news@news.prolabsupport.kz>" в env, когда
// заведёшь поддомен и подтвердишь его в Resend (SPF/DKIM/DMARC).
const CAMPAIGN_FROM = process.env.CAMPAIGN_FROM || 'ProLabSupport <news@prolabsupport.kz>';
const SEND_BATCH = 20;          // писем за «пачку»
const SEND_PAUSE_MS = 1500;     // пауза между пачками (троттлинг)

// ── Провайдер отправки: 'selzy' или 'resend' (по умолчанию resend) ──────────
// Для Selzy: CAMPAIGN_PROVIDER=selzy, SELZY_API_KEY=..., SELZY_LIST_ID=<id списка
// в Selzy, нужен для ссылки отписки>, а отправитель берётся из CAMPAIGN_FROM
// (или переопредели SELZY_SENDER_EMAIL — это ДОЛЖЕН быть подтверждённый в Selzy
// адрес на поддомене, напр. news@client.prolabsupport.kz).
const PROVIDER = (process.env.CAMPAIGN_PROVIDER || 'resend').toLowerCase();
const SELZY_KEY = process.env.SELZY_API_KEY;
const SELZY_LIST_ID = process.env.SELZY_LIST_ID;
const SELZY_INTERVAL_MS = parseInt(process.env.SELZY_INTERVAL_MS || '1100', 10); // лимит Selzy — 60/мин
const FROM_NAME = (CAMPAIGN_FROM.match(/^([^<]+)</) || [null, 'ProLabSupport'])[1].trim();
const FROM_EMAIL = (CAMPAIGN_FROM.match(/<([^>]+)>/) || [null, CAMPAIGN_FROM])[1].trim();
const SELZY_SENDER_EMAIL = process.env.SELZY_SENDER_EMAIL || FROM_EMAIL;

// ── Фирменное оформление письма ─────────────────────────────────────────────
// Логотип берётся по абсолютному URL (в письме нельзя относительные пути).
const BRAND = {
  accent: '#C53B2F',                                   // фирменный красный
  logo:   process.env.CAMPAIGN_LOGO_URL || `${APP_BASE}/assets/logo-wordmark.png`,
};
// Единая подпись компании. Телефон/адрес — через env (не выдумываем): если не
// задано, строка просто не выводится. Настрой CAMPAIGN_SIG_* в окружении.
const SIG = {
  company: process.env.CAMPAIGN_SIG_COMPANY || 'ProLabSupport',
  tagline: process.env.CAMPAIGN_SIG_TAGLINE || 'Комплексное оснащение лабораторий и сервис аналитического оборудования',
  site:    process.env.CAMPAIGN_SIG_SITE    || 'prolabsupport.kz',
  email:   process.env.CAMPAIGN_SIG_EMAIL   || 'info@prolabsupport.kz',
  phone:   process.env.CAMPAIGN_SIG_PHONE   || '',
  address: process.env.CAMPAIGN_SIG_ADDR    || 'Казахстан',
};
const MAX_FILE_BYTES = parseInt(process.env.CAMPAIGN_MAX_FILE_MB || '7', 10) * 1024 * 1024;

const sleep = ms => new Promise(r => setTimeout(r, ms));
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function fmtSize(b) {
  b = Number(b) || 0;
  if (b < 1024) return b + ' Б';
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' КБ';
  return (b / 1024 / 1024).toFixed(1) + ' МБ';
}

let _schema = null;
function ensureSchema() {
  if (_schema) return _schema;
  _schema = (async () => {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaign_audience (
        email VARCHAR(200) PRIMARY KEY,
        company_id BIGINT,
        company_name VARCHAR(400),
        industry_id VARCHAR(40),
        industry_name VARCHAR(200),
        source VARCHAR(20),
        contact_name VARCHAR(200),
        synced_at TIMESTAMPTZ DEFAULT NOW());
      CREATE INDEX IF NOT EXISTS idx_camp_aud_ind ON ticketsmodule_campaign_audience(industry_id);
      CREATE INDEX IF NOT EXISTS idx_camp_aud_comp ON ticketsmodule_campaign_audience(company_id);
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaigns (
        id SERIAL PRIMARY KEY,
        name VARCHAR(300),
        subject VARCHAR(400),
        from_name VARCHAR(200),
        body_html TEXT,
        created_by INTEGER,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        sent_at TIMESTAMPTZ,
        status VARCHAR(20) DEFAULT 'draft',
        total INTEGER DEFAULT 0, sent INTEGER DEFAULT 0, failed INTEGER DEFAULT 0);
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaign_recipients (
        id SERIAL PRIMARY KEY,
        campaign_id INTEGER REFERENCES ticketsmodule_campaigns(id) ON DELETE CASCADE,
        email VARCHAR(200),
        company_name VARCHAR(400),
        status VARCHAR(20) DEFAULT 'pending',
        error TEXT, message_id TEXT, at TIMESTAMPTZ);
      CREATE INDEX IF NOT EXISTS idx_camp_rec_cid ON ticketsmodule_campaign_recipients(campaign_id);
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaign_suppression (
        email VARCHAR(200) PRIMARY KEY,
        reason VARCHAR(60),
        at TIMESTAMPTZ DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaign_files (
        id SERIAL PRIMARY KEY,
        campaign_id INTEGER REFERENCES ticketsmodule_campaigns(id) ON DELETE CASCADE,
        filename VARCHAR(300),
        mime VARCHAR(120),
        size_bytes INTEGER,
        kind VARCHAR(10) DEFAULT 'link',   -- 'link' (кнопка «Скачать») или 'attach' (вложение в письмо)
        token VARCHAR(48),
        data BYTEA,
        created_at TIMESTAMPTZ DEFAULT NOW());
      CREATE INDEX IF NOT EXISTS idx_camp_files_cid ON ticketsmodule_campaign_files(campaign_id);
      CREATE UNIQUE INDEX IF NOT EXISTS idx_camp_files_token ON ticketsmodule_campaign_files(token);
      CREATE TABLE IF NOT EXISTS ticketsmodule_campaign_assets (
        akey VARCHAR(40) PRIMARY KEY,          -- напр. 'footer_logo'
        mime VARCHAR(120),
        data BYTEA,
        updated_by INTEGER,
        updated_at TIMESTAMPTZ DEFAULT NOW());
    `);
  })().catch(e => { _schema = null; throw e; });
  return _schema;
}

// ── Справочник сфер (INDUSTRY) ──────────────────────────────────────────────
let _indMap = null, _indAt = 0;
async function industryMap() {
  if (_indMap && Date.now() - _indAt < 6 * 3600 * 1000) return _indMap;
  const map = {};
  try {
    const { result } = await b24('crm.status.list', { filter: { ENTITY_ID: 'INDUSTRY' }, order: { SORT: 'ASC' } });
    (result || []).forEach(s => { map[s.STATUS_ID] = s.NAME; });
  } catch (e) { console.error('industryMap:', e.message); }
  _indMap = map; _indAt = Date.now();
  return map;
}

function extractEmails(mf) {
  if (!mf) return [];
  const arr = Array.isArray(mf) ? mf : [mf];
  return [...new Set(arr.map(x => (x && typeof x === 'object') ? x.VALUE : x)
    .filter(Boolean).map(e => String(e).trim().toLowerCase()).filter(e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)))];
}

// ── Синхронизация аудитории из Bitrix (компании + контакты) ─────────────────
let _syncing = false, _lastSync = null;
async function syncAudience() {
  if (_syncing) return { skipped: 'running' };
  _syncing = true;
  await ensureSchema();
  const indMap = await industryMap();
  const rows = new Map(); // email -> row
  try {
    // 1) Компании: TITLE + INDUSTRY + EMAIL
    let start = 0, guard = 0;
    while (guard++ < 400) {
      const res = await b24('crm.company.list', { select: ['ID', 'TITLE', 'INDUSTRY', 'EMAIL'], order: { ID: 'ASC' }, start });
      const arr = res.result || [];
      for (const c of arr) {
        const industryId = c.INDUSTRY || '';
        for (const em of extractEmails(c.EMAIL)) {
          if (!rows.has(em)) rows.set(em, { email: em, companyId: c.ID, companyName: c.TITLE || '', industryId, industryName: indMap[industryId] || (industryId ? industryId : 'Без сферы'), source: 'company', contactName: null });
        }
      }
      if (res.next == null) break; start = res.next; await sleep(120);
    }
    // 2) Контакты по компаниям (батчами по 50 id) — email контактов, сфера от компании
    const compIndustry = {}; // companyId -> {industryId, name}
    { const r = await pool.query('SELECT DISTINCT company_id, industry_id, industry_name, company_name FROM ticketsmodule_campaign_audience'); r.rows.forEach(x => { compIndustry[x.company_id] = { industryId: x.industry_id, industryName: x.industry_name, companyName: x.company_name }; }); }
    // список id компаний берём из уже собранных email-строк + докидываем из Bitrix постранично контакты
    let cstart = 0, cguard = 0;
    while (cguard++ < 800) {
      const res = await b24('crm.contact.list', { select: ['ID', 'NAME', 'LAST_NAME', 'EMAIL', 'COMPANY_ID'], order: { ID: 'ASC' }, start: cstart });
      const arr = res.result || [];
      for (const ct of arr) {
        const emails = extractEmails(ct.EMAIL); if (!emails.length) continue;
        const cid = ct.COMPANY_ID || null;
        // сфера/название компании — из карты собранных (если контакт привязан к компании, что уже в аудитории)
        let info = null;
        if (cid) {
          // найдём среди уже собранных email-строк компанию
          for (const v of rows.values()) { if (String(v.companyId) === String(cid)) { info = v; break; } }
        }
        const nm = [ct.LAST_NAME, ct.NAME].filter(Boolean).join(' ').trim() || null;
        for (const em of emails) {
          if (!rows.has(em)) rows.set(em, {
            email: em, companyId: cid, companyName: info ? info.companyName : '',
            industryId: info ? info.industryId : '', industryName: info ? info.industryName : 'Без сферы',
            source: 'contact', contactName: nm,
          });
        }
      }
      if (res.next == null) break; cstart = res.next; await sleep(120);
    }
    // 3) Перезаписываем кэш
    await pool.query('DELETE FROM ticketsmodule_campaign_audience');
    const vals = [...rows.values()];
    for (let i = 0; i < vals.length; i += 500) {
      const chunk = vals.slice(i, i + 500);
      const ph = []; const params = [];
      chunk.forEach((v, j) => {
        const b = j * 7;
        ph.push(`($${b+1},$${b+2},$${b+3},$${b+4},$${b+5},$${b+6},$${b+7})`);
        params.push(v.email, v.companyId || null, v.companyName || '', v.industryId || '', v.industryName || 'Без сферы', v.source, v.contactName);
      });
      if (chunk.length) await pool.query(
        `INSERT INTO ticketsmodule_campaign_audience (email, company_id, company_name, industry_id, industry_name, source, contact_name) VALUES ${ph.join(',')} ON CONFLICT (email) DO NOTHING`, params);
    }
    _lastSync = new Date().toISOString();
    console.log(`campaigns: аудитория синхронизирована — ${vals.length} e-mail`);
    return { ok: true, emails: vals.length };
  } catch (e) {
    console.error('syncAudience error:', e.message);
    return { ok: false, error: e.message };
  } finally { _syncing = false; }
}

async function getIndustries() {
  await ensureSchema();
  const { rows } = await pool.query(
    `SELECT industry_id, MAX(industry_name) AS name, COUNT(DISTINCT company_id) AS companies, COUNT(*) AS emails
       FROM ticketsmodule_campaign_audience GROUP BY industry_id ORDER BY name`);
  return { lastSync: _lastSync, syncing: _syncing, industries: rows.map(r => ({ id: r.industry_id, name: r.name || 'Без сферы', companies: Number(r.companies), emails: Number(r.emails) })) };
}

async function getCompanies(industryId) {
  await ensureSchema();
  const { rows } = await pool.query(
    `SELECT company_id, MAX(company_name) AS name,
            json_agg(json_build_object('email', email, 'name', contact_name, 'source', source) ORDER BY email) AS emails
       FROM ticketsmodule_campaign_audience WHERE industry_id=$1 GROUP BY company_id ORDER BY name`, [industryId || '']);
  return rows.map(r => ({ companyId: r.company_id, name: r.name || ('Компания #' + r.company_id), emails: r.emails || [] }));
}

// Сквозной поиск компаний по ВСЕЙ базе (независимо от выбранной сферы) —
// по названию компании ИЛИ по e-mail. Возвращает и название сферы для метки.
async function searchCompanies(q) {
  await ensureSchema();
  const like = '%' + String(q || '').trim().toLowerCase() + '%';
  // Группируем по company_id (как в getCompanies). Ищем по названию ИЛИ e-mail.
  const { rows } = await pool.query(
    `SELECT company_id, MAX(company_name) AS name, MAX(industry_name) AS industry,
            json_agg(json_build_object('email', email, 'name', contact_name, 'source', source) ORDER BY email) AS emails
       FROM ticketsmodule_campaign_audience
       WHERE LOWER(company_name) LIKE $1 OR LOWER(email) LIKE $1
       GROUP BY company_id
       ORDER BY MAX(company_name) NULLS LAST LIMIT 300`, [like]);
  return rows.map(r => ({ companyId: r.company_id, name: r.name || ('Компания #' + r.company_id), industry: r.industry || '', emails: r.emails || [] }));
}

// ── Кампании ────────────────────────────────────────────────────────────────
async function createCampaign(payload, byBid) {
  await ensureSchema();
  const { name, subject, fromName, bodyHtml } = payload || {};
  const { rows } = await pool.query(
    `INSERT INTO ticketsmodule_campaigns (name, subject, from_name, body_html, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [name || 'Без названия', subject || '', fromName || '', bodyHtml || '', byBid || null]);
  return { id: rows[0].id };
}
async function updateCampaign(id, payload) {
  await ensureSchema();
  const { name, subject, fromName, bodyHtml } = payload || {};
  await pool.query('UPDATE ticketsmodule_campaigns SET name=$1, subject=$2, from_name=$3, body_html=$4 WHERE id=$5 AND status=\'draft\'',
    [name || '', subject || '', fromName || '', bodyHtml || '', id]);
  return { ok: true };
}
async function listCampaigns() {
  await ensureSchema();
  const { rows } = await pool.query('SELECT id, name, subject, status, total, sent, failed, created_at, sent_at FROM ticketsmodule_campaigns ORDER BY id DESC LIMIT 200');
  return rows;
}
async function getCampaign(id) {
  await ensureSchema();
  const { rows } = await pool.query('SELECT * FROM ticketsmodule_campaigns WHERE id=$1', [id]);
  if (!rows.length) return null;
  const rec = await pool.query('SELECT status, COUNT(*)::int n FROM ticketsmodule_campaign_recipients WHERE campaign_id=$1 GROUP BY status', [id]);
  const counts = {}; rec.rows.forEach(r => { counts[r.status] = r.n; });
  return { ...rows[0], counts };
}
async function deleteCampaign(id) {
  await ensureSchema();
  await pool.query('DELETE FROM ticketsmodule_campaigns WHERE id=$1 AND status IN (\'draft\',\'sent\',\'failed\')', [id]);
  return { ok: true };
}
async function setRecipients(campaignId, emails) {
  await ensureSchema();
  const uniq = [...new Set((emails || []).map(e => String(e).trim().toLowerCase()).filter(Boolean))];
  await pool.query('DELETE FROM ticketsmodule_campaign_recipients WHERE campaign_id=$1', [campaignId]);
  // подтягиваем название компании к каждому email
  for (let i = 0; i < uniq.length; i += 500) {
    const chunk = uniq.slice(i, i + 500);
    const ph = []; const params = [campaignId];
    chunk.forEach((em, j) => { ph.push(`($1,$${j+2})`); params.push(em); });
    await pool.query(
      `INSERT INTO ticketsmodule_campaign_recipients (campaign_id, email, company_name)
       SELECT $1, e.email, COALESCE(a.company_name,'')
         FROM unnest(ARRAY[${chunk.map((_, j) => `$${j+2}`).join(',')}]::text[]) e(email)
         LEFT JOIN ticketsmodule_campaign_audience a ON a.email=e.email`, params);
  }
  await pool.query('UPDATE ticketsmodule_campaigns SET total=(SELECT COUNT(*) FROM ticketsmodule_campaign_recipients WHERE campaign_id=$1) WHERE id=$1', [campaignId]);
  return { ok: true, count: uniq.length };
}

// ── Файлы кампании (вложения / ссылки на скачивание) ────────────────────────
async function addFile(campaignId, { filename, mime, dataBase64, kind }) {
  await ensureSchema();
  const buf = Buffer.from(String(dataBase64 || ''), 'base64');
  if (!buf.length) throw new Error('Пустой файл');
  if (buf.length > MAX_FILE_BYTES) throw new Error('Файл больше ' + fmtSize(MAX_FILE_BYTES));
  const k = kind === 'attach' ? 'attach' : 'link';
  const token = crypto.randomBytes(18).toString('base64url');
  const { rows } = await pool.query(
    `INSERT INTO ticketsmodule_campaign_files (campaign_id, filename, mime, size_bytes, kind, token, data)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, filename, mime, size_bytes, kind, token`,
    [campaignId, String(filename || 'file').slice(0, 300), String(mime || 'application/octet-stream').slice(0, 120), buf.length, k, token, buf]);
  return rows[0];
}
async function listFiles(campaignId) {
  await ensureSchema();
  const { rows } = await pool.query(
    'SELECT id, filename, mime, size_bytes, kind, token FROM ticketsmodule_campaign_files WHERE campaign_id=$1 ORDER BY id', [campaignId]);
  return rows;
}
async function deleteFile(campaignId, fileId) {
  await ensureSchema();
  await pool.query('DELETE FROM ticketsmodule_campaign_files WHERE id=$1 AND campaign_id=$2', [fileId, campaignId]);
  return { ok: true };
}
async function setFileKind(campaignId, fileId, kind) {
  await ensureSchema();
  await pool.query('UPDATE ticketsmodule_campaign_files SET kind=$1 WHERE id=$2 AND campaign_id=$3',
    [kind === 'attach' ? 'attach' : 'link', fileId, campaignId]);
  return { ok: true };
}
async function getFileByToken(token) {
  await ensureSchema();
  const { rows } = await pool.query(
    'SELECT filename, mime, data FROM ticketsmodule_campaign_files WHERE token=$1', [String(token || '')]);
  return rows[0] || null;
}

// Токен отписки (стабильный на email).
function unsubToken(email) {
  const mac = crypto.createHmac('sha256', JWT_SECRET).update('unsub:' + email).digest('base64url').slice(0, 16);
  return Buffer.from(email).toString('base64url') + '.' + mac;
}
function unsubVerify(token) {
  try {
    const [b, mac] = String(token).split('.');
    const email = Buffer.from(b, 'base64url').toString('utf8');
    const good = crypto.createHmac('sha256', JWT_SECRET).update('unsub:' + email).digest('base64url').slice(0, 16);
    return mac === good ? email : null;
  } catch (e) { return null; }
}
async function suppress(email, reason) {
  await ensureSchema();
  await pool.query('INSERT INTO ticketsmodule_campaign_suppression (email, reason) VALUES ($1,$2) ON CONFLICT (email) DO NOTHING', [String(email).toLowerCase(), reason || 'unsub']);
  return { ok: true };
}

function personalize(html, rec) {
  return String(html || '')
    .replace(/\{\{\s*Компания\s*\}\}/gi, esc(rec.company_name || ''))
    .replace(/\{\{\s*Company\s*\}\}/gi, esc(rec.company_name || ''));
}
// Кнопки-«вложения ссылкой»: файлы, которые не аттачим, а даём скачать.
function linkFilesBlock(linkFiles) {
  if (!linkFiles || !linkFiles.length) return '';
  const rows = linkFiles.map(f => `
    <tr><td style="padding:5px 0">
      <a href="${APP_BASE}/api/campaigns/file/${f.token}" target="_blank"
         style="display:inline-block;background:#f5f6fa;border:1px solid #e3e6ef;border-radius:8px;padding:11px 16px;color:#1a1e27;text-decoration:none;font-size:14px;font-weight:600;font-family:Arial,sans-serif">
        📎 ${esc(f.filename)} <span style="color:#9ca3af;font-weight:400">· ${fmtSize(f.size_bytes)}</span>
      </a></td></tr>`).join('');
  return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:20px">
    <tr><td style="font-size:12px;color:#9ca3af;text-transform:uppercase;letter-spacing:.5px;font-weight:700;padding-bottom:4px;font-family:Arial,sans-serif">Материалы для скачивания</td></tr>
    ${rows}
  </table>`;
}

// Фирменная обёртка (стиль как в рассылках Selzy): тело → большой фирменный
// блок-логотип (логотип + слоган + партнёры, одним изображением) → отписка.
function wrapEmail(bodyHtml, unsubUrl, opts = {}) {
  // Логотип футера: заменяемый через интерфейс (admin/marketolog) — отдаётся из БД
  // публичным эндпоинтом /api/campaigns/logo; если не заменён, эндпоинт вернёт
  // дефолтный /assets/company-full-logo.png. Можно переопределить env-переменной.
  const footerLogo = process.env.CAMPAIGN_FOOTER_LOGO_URL || `${APP_BASE}/api/campaigns/logo`;
  const footContacts = [
    SIG.address ? esc(SIG.address) : '',
    SIG.site ? esc(SIG.site) : '',
  ].filter(Boolean).join(' · ');

  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet"></head>
<body style="margin:0;padding:0;background:#eef0f5;-webkit-text-size-adjust:100%;font-family:'Montserrat',Arial,Helvetica,sans-serif">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#eef0f5">
 <tr><td align="center" style="padding:24px 12px">
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="640" style="max-width:640px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 2px 12px rgba(20,25,40,.07)">
   <!-- Тело -->
   <tr><td style="padding:34px 36px 10px;font-family:'Montserrat',Arial,Helvetica,sans-serif;color:#2a2f3a;font-size:15px;line-height:1.7">
     ${bodyHtml}
     ${linkFilesBlock(opts.linkFiles)}
   </td></tr>
   <!-- Фирменный блок: логотип + слоган + партнёры (одно изображение) -->
   <tr><td align="center" style="padding:24px 36px 6px">
     <img src="${footerLogo}" alt="${esc(SIG.company)}" width="520" style="width:100%;max-width:520px;height:auto;display:block;border:0">
   </td></tr>
   <!-- Отписка -->
   <tr><td style="padding:16px 36px 26px;font-family:Arial,Helvetica,sans-serif">
     <div style="border-top:1px solid #eef0f5;padding-top:14px;font-size:12px;color:#9ca3af;line-height:1.6">${esc(SIG.company)}${footContacts ? ' · ' + footContacts : ''}<br>
     Вы получили это письмо как клиент ${esc(SIG.company)}. <a href="${unsubUrl}" style="color:#9ca3af;text-decoration:underline">Отписаться</a></div>
   </td></tr>
  </table>
 </td></tr>
</table>
</body></html>`;
}

// Файлы кампании для отправки: link-файлы → кнопки в письме, attach-файлы →
// вложения (грузим данные один раз на всю кампанию).
async function filesForSend(campaignId) {
  const { rows } = await pool.query(
    'SELECT filename, mime, size_bytes, kind, token, data FROM ticketsmodule_campaign_files WHERE campaign_id=$1 ORDER BY id', [campaignId]);
  return rows.map(r => ({
    filename: r.filename, mime: r.mime, size_bytes: r.size_bytes, kind: r.kind, token: r.token,
    base64: r.kind === 'attach' && r.data ? Buffer.from(r.data).toString('base64') : null,
  }));
}

async function sendOne(rec, campaign, files) {
  files = files || [];
  const linkFiles = files.filter(f => f.kind === 'link');
  const attachFiles = files.filter(f => f.kind === 'attach');
  const unsubUrl = `${APP_BASE}/api/campaigns/unsub?t=${unsubToken(rec.email)}`;
  const html = wrapEmail(personalize(campaign.body_html, rec), unsubUrl, { linkFiles });
  if (PROVIDER === 'selzy') return sendOneSelzy(rec, campaign, html, attachFiles);
  return sendOneResend(rec, campaign, html, unsubUrl, attachFiles);
}

async function sendOneResend(rec, campaign, html, unsubUrl, attachFiles) {
  const from = campaign.from_name ? campaign.from_name.replace(/<[^>]*>/g, '').trim() + ' <' + FROM_EMAIL + '>' : CAMPAIGN_FROM;
  const payload = { from, to: [rec.email], subject: campaign.subject || '', html,
    headers: { 'List-Unsubscribe': `<${unsubUrl}>`, 'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click' } };
  if (attachFiles && attachFiles.length) {
    payload.attachments = attachFiles.map(f => ({ filename: f.filename, content: f.base64 }));
  }
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { 'Authorization': `Bearer ${RESEND_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const d = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((d && (d.message || d.error)) || ('HTTP ' + res.status));
  return d.id || null;
}

// Отправка через Selzy (ex-Unisender) методом sendEmail. Отправитель — подтверждённый
// в Selzy адрес на поддомене. list_id нужен Selzy для ссылки отписки.
async function sendOneSelzy(rec, campaign, html, attachFiles) {
  if (!SELZY_KEY) throw new Error('SELZY_API_KEY не задан');
  if (!SELZY_LIST_ID) throw new Error('SELZY_LIST_ID не задан');
  const senderName = (campaign.from_name ? campaign.from_name.replace(/<[^>]*>/g, '').trim() : '') || FROM_NAME;
  const params = new URLSearchParams();
  params.set('format', 'json');
  params.set('api_key', SELZY_KEY);
  params.set('email', rec.email);
  params.set('sender_name', senderName);
  params.set('sender_email', SELZY_SENDER_EMAIL);
  params.set('subject', campaign.subject || '');
  params.set('body', html);
  params.set('list_id', String(SELZY_LIST_ID));
  params.set('track_read', '0');
  params.set('track_links', '0');
  // Вложения: Selzy sendEmail принимает attachments[имя_файла]=содержимое (base64).
  if (attachFiles && attachFiles.length) {
    for (const f of attachFiles) params.set(`attachments[${f.filename}]`, f.base64 || '');
  }
  const res = await fetch('https://api.selzy.com/en/api/sendEmail', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString(),
  });
  const d = await res.json().catch(() => ({}));
  if (d && d.error) throw new Error(String(d.error) + (d.code ? ' [' + d.code + ']' : ''));
  const r = d && d.result;
  const id = Array.isArray(r) ? (r[0] && (r[0].id || r[0].email_id)) : (r && (r.email_id || r.id));
  return id ? String(id) : null;
}

// Запуск рассылки (в фоне). Троттлинг + стоп-лист + запись статусов.
async function sendCampaign(campaignId) {
  await ensureSchema();
  if (PROVIDER === 'selzy') {
    if (!SELZY_KEY) return { ok: false, error: 'SELZY_API_KEY не задан' };
    if (!SELZY_LIST_ID) return { ok: false, error: 'SELZY_LIST_ID не задан' };
  } else if (!RESEND_KEY) {
    return { ok: false, error: 'RESEND_API_KEY не задан' };
  }
  const c = (await pool.query('SELECT * FROM ticketsmodule_campaigns WHERE id=$1', [campaignId])).rows[0];
  if (!c) return { ok: false, error: 'Кампания не найдена' };
  if (c.status === 'sending') return { ok: false, error: 'Рассылка уже идёт' };
  await pool.query('UPDATE ticketsmodule_campaigns SET status=\'sending\', sent_at=NOW() WHERE id=$1', [campaignId]);
  (async () => {
    let sent = 0, failed = 0;
    try {
      const files = await filesForSend(campaignId);
      const { rows: recs } = await pool.query(
        `SELECT r.* FROM ticketsmodule_campaign_recipients r
           WHERE r.campaign_id=$1 AND r.status='pending'
             AND NOT EXISTS (SELECT 1 FROM ticketsmodule_campaign_suppression s WHERE s.email=r.email)`, [campaignId]);
      for (let i = 0; i < recs.length; i += SEND_BATCH) {
        const batch = recs.slice(i, i + SEND_BATCH);
        for (const rec of batch) {
          try {
            const mid = await sendOne(rec, c, files);
            await pool.query('UPDATE ticketsmodule_campaign_recipients SET status=\'sent\', message_id=$1, at=NOW() WHERE id=$2', [mid, rec.id]);
            sent++;
          } catch (e) {
            await pool.query('UPDATE ticketsmodule_campaign_recipients SET status=\'failed\', error=$1, at=NOW() WHERE id=$2', [String(e.message).slice(0, 300), rec.id]);
            failed++;
          }
          // Selzy: не чаще 60 писем/мин — держим паузу между письмами.
          if (PROVIDER === 'selzy') await sleep(SELZY_INTERVAL_MS);
        }
        await pool.query('UPDATE ticketsmodule_campaigns SET sent=$1, failed=$2 WHERE id=$3', [sent, failed, campaignId]);
        if (i + SEND_BATCH < recs.length) await sleep(SEND_PAUSE_MS);
      }
      // отписанных помечаем
      await pool.query(`UPDATE ticketsmodule_campaign_recipients r SET status='unsub'
        WHERE r.campaign_id=$1 AND r.status='pending' AND EXISTS (SELECT 1 FROM ticketsmodule_campaign_suppression s WHERE s.email=r.email)`, [campaignId]);
      await pool.query('UPDATE ticketsmodule_campaigns SET status=\'sent\', sent=$1, failed=$2 WHERE id=$3', [sent, failed, campaignId]);
      console.log(`campaigns: кампания #${campaignId} — отправлено ${sent}, ошибок ${failed}`);
    } catch (e) {
      console.error('sendCampaign run error:', e.message);
      await pool.query('UPDATE ticketsmodule_campaigns SET status=\'failed\' WHERE id=$1', [campaignId]).catch(() => {});
    }
  })();
  return { ok: true, started: true };
}

// ── Ассеты рассылок (логотип письма) ────────────────────────────────────────
// Логотип футера письма можно заменить из интерфейса (admin/marketolog). Храним
// картинку в БД; отдаётся публично через /api/campaigns/logo, а письма ссылаются
// на этот URL. Размер/поля подгоняются автоматически самим шаблоном (img width:100%).
async function getAsset(key) {
  await ensureSchema();
  const { rows } = await pool.query('SELECT mime, data, updated_at FROM ticketsmodule_campaign_assets WHERE akey=$1', [key]);
  if (!rows.length || !rows[0].data) return null;
  return { mime: rows[0].mime || 'image/png', data: rows[0].data, updatedAt: rows[0].updated_at };
}
async function setAsset(key, mime, buffer, userId) {
  await ensureSchema();
  await pool.query(
    `INSERT INTO ticketsmodule_campaign_assets (akey, mime, data, updated_by, updated_at)
       VALUES ($1,$2,$3,$4,NOW())
       ON CONFLICT (akey) DO UPDATE SET mime=EXCLUDED.mime, data=EXCLUDED.data, updated_by=EXCLUDED.updated_by, updated_at=NOW()`,
    [key, mime || 'image/png', buffer, userId || null]);
  return { ok: true };
}
async function deleteAsset(key) {
  await ensureSchema();
  await pool.query('DELETE FROM ticketsmodule_campaign_assets WHERE akey=$1', [key]);
  return { ok: true };
}

module.exports = {
  ensureSchema, syncAudience, getIndustries, getCompanies, searchCompanies,
  createCampaign, updateCampaign, listCampaigns, getCampaign, deleteCampaign,
  setRecipients, sendCampaign, suppress, unsubVerify, industryMap,
  addFile, listFiles, deleteFile, setFileKind, getFileByToken,
  getAsset, setAsset, deleteAsset,
};
