const express = require('express');
const router = express.Router();
const { pool, requireAuth, canEdit, canDelete, auditLog } = require('../auth');
const { b24 } = require('../bitrix');
const { getItem } = require('../relations');
const { getRootDealManager, getContractFromChain, fmtDateOnly, markRecentlyDeleted } = require('../bitrix-lookups');
const { notifyJobAssigned } = require('../manager-notifications');

// All start/end values from the client are naive "YYYY-MM-DDTHH:mm" strings
// (no timezone) representing local Kazakhstan wall-clock time. We must be
// explicit about that on both sides of Postgres, since a bare TIMESTAMPTZ
// write/read without this would silently assume UTC and shift every time by
// several hours.
const TZ = 'Asia/Almaty';
const crypto = require('crypto');
const { USERS } = require('../constants');

// Fingerprint of {engineerId, start, end} — used on both sides of the sync
// to tell a genuine external Bitrix change apart from Bitrix simply echoing
// back an update we ourselves just pushed.
function computeSyncHash(engineerId, start, end) {
  return crypto.createHash('sha256').update(`${engineerId}|${start}|${end}`).digest('hex').slice(0, 16);
}

// Reverse-lookup: planner resource name → Bitrix user ID, needed to push an
// engineer reassignment back to Bitrix. Prefers the live staff roster
// (bitrixUserId backfilled by the staff sync); falls back to the USERS map.
async function resolveBitrixUserId(resourceName) {
  try {
    const { rows } = await pool.query(`SELECT value FROM ticketsmodule_planner_config WHERE key='depts'`);
    const adminDepts = rows[0]?.value || [];
    for (const d of adminDepts) {
      const m = d.members.find(x => x.name === resourceName);
      if (m?.bitrixUserId) return m.bitrixUserId;
    }
  } catch (e) { /* fall through to USERS map */ }
  const found = Object.entries(USERS).find(([, name]) => name === resourceName);
  return found ? parseInt(found[0], 10) : null;
}

const SELECT_COLS = `
  id, group_id, resource, title, type,
  to_char(start_at AT TIME ZONE '${TZ}', 'YYYY-MM-DD"T"HH24:MI') AS start_str,
  to_char(end_at AT TIME ZONE '${TZ}', 'YYYY-MM-DD"T"HH24:MI') AS end_str,
  all_day, confirmed, note, fields, clients, bitrix_item_id, source
`;

// ── Helpers ───────────────────────────────────────────────────────────────
function rowToEvent(r) {
  return {
    id: r.id,
    groupId: r.group_id,
    resource: r.resource,
    title: r.title,
    type: r.type,
    start: r.start_str,
    end: r.end_str,
    allDay: r.all_day,
    confirmed: r.confirmed,
    note: r.note,
    fields: r.fields || {},
    clients: r.clients || [],
    bitrixItemId: r.bitrix_item_id,
    source: r.source,
  };
}

async function insertOne(client, { resource, title, type, start, end, allDay, confirmed, note, fields, clients, createdBy, bitrixItemId, source }) {
  const { rows } = await client.query(
    `INSERT INTO ticketsmodule_planner_events
      (group_id, resource, title, type, start_at, end_at, all_day, confirmed, note, fields, clients, created_by, bitrix_item_id, source)
     VALUES (0, $1,$2,$3, $4::timestamp AT TIME ZONE '${TZ}', $5::timestamp AT TIME ZONE '${TZ}', $6,$7,$8,$9,$10,$11,$12,$13)
     RETURNING id`,
    [resource, title || '', type, start, end, !!allDay, !!confirmed, note || '',
     JSON.stringify(fields || {}), JSON.stringify(clients || []), createdBy || null,
     bitrixItemId || null, source || 'manual']
  );
  return rows[0];
}

async function fetchByIds(client, ids) {
  if (!ids.length) return [];
  const { rows } = await client.query(
    `SELECT ${SELECT_COLS} FROM ticketsmodule_planner_events WHERE id = ANY($1::int[]) ORDER BY id`, [ids]
  );
  return rows;
}

// ── GET /api/planner/events/version — дешёвый маркер изменений для поллинга ──
// Фронт тянет полный список событий только когда маркер изменился (экономит
// egress из Supabase). Объявлен ПЕРЕД /events, чтобы не перехватывался.
router.get('/events/version', requireAuth(), async (req, res) => {
  try {
    const { tableVersion } = require('../db-version');
    res.json({ v: await tableVersion('ticketsmodule_planner_events') });
  } catch (e) {
    console.error('GET /api/planner/events/version error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /api/planner/events — full list ────────────────────────────────────
router.get('/events', requireAuth(), async (req, res) => {
  try {
    const { rows } = await pool.query(`SELECT ${SELECT_COLS} FROM ticketsmodule_planner_events ORDER BY id`);
    res.json({ events: rows.map(rowToEvent) });
  } catch (e) {
    console.error('GET /api/planner/events error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /api/planner/events — create (with optional co-assignees) ────────
router.post('/events', requireAuth(), async (req, res) => {
  const { resource, title, type, start, end, allDay, confirmed, note, fields, clients, coAssignees } = req.body;
  if (!resource || !start || !end) return res.status(400).json({ error: 'resource, start, end are required' });

  // Role gate: viewer — none; engineer — only events assigned to themselves;
  // admin/manager/logist/coordinator — any. The new event's owner is `resource`.
  const ownerObj = { engineer: resource, assignedById: await resolveBitrixUserId(resource) };
  if (!canEdit(req.user, ownerObj)) return res.status(403).json({ error: 'Недостаточно прав' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const common = { title, type, start, end, allDay, confirmed, note, fields, clients, createdBy: req.user?.username };

    const primary = await insertOne(client, { ...common, resource });
    await client.query('UPDATE ticketsmodule_planner_events SET group_id=$1 WHERE id=$1', [primary.id]);

    const ids = [primary.id];
    for (const name of (coAssignees || [])) {
      if (!name || name === resource) continue;
      const sib = await insertOne(client, { ...common, resource: name });
      await client.query('UPDATE ticketsmodule_planner_events SET group_id=$1 WHERE id=$2', [primary.id, sib.id]);
      ids.push(sib.id);
    }

    const created = await fetchByIds(client, ids);
    await client.query('COMMIT');
    res.json({ events: created.map(rowToEvent) });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /api/planner/events error:', e.message);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// ── PUT /api/planner/events/:id — update (syncs co-assignee group) ────────
// ── Outbound push: planner edit → Bitrix (dates + engineer only) ──────────
async function pushEventToBitrix(bitrixItemId, resource, start, end) {
  const engineerId = await resolveBitrixUserId(resource);
  if (!engineerId) {
    console.warn(`Outbound push: no Bitrix user ID found for "${resource}" — skipping push for item ${bitrixItemId}`);
    return;
  }
  const sDateOnly = start.slice(0, 10), eDateOnly = end.slice(0, 10);
  const hash = computeSyncHash(engineerId, sDateOnly, eDateOnly);
  try {
    await b24('crm.item.update', {
      entityTypeId: 1058, id: bitrixItemId,
      fields: {
        ufCrm8_1732856367: engineerId,
        ufCrm8_1764742554715: sDateOnly,
        ufCrm8_1764742724958: eDateOnly,
      },
    });
    await pool.query('UPDATE ticketsmodule_planner_events SET bitrix_sync_hash=$1 WHERE bitrix_item_id=$2', [hash, bitrixItemId]);
  } catch (e) {
    console.error(`Outbound push to Bitrix failed for item ${bitrixItemId}:`, e.message);
  }
}

// Sends the same rich "job changed" notification the inbound webhook sends,
// but for edits that originated in the planner itself. The inbound echo that
// results from our own outbound push is deliberately NOT treated as a new
// change (see the hash check in syncPlannerEvent) — so without this, nobody
// would ever be told about a change made by dragging/editing in the planner.
async function notifyOutboundChange(bitrixItemId, resource, start, end, oldRow, changeFlags) {
  const item = await getItem(1058, bitrixItemId);
  if (!item) return;

  const engineerId = await resolveBitrixUserId(resource);
  const engineerName = resource;
  const mgr = await getRootDealManager(1058, item);
  const managerId = mgr?.managerId;
  const managerName = managerId ? (USERS[managerId] || `Пользователь #${managerId}`) : '';
  const contractLabel = await getContractFromChain(1058, item);
  const companyId = parseInt(item.companyId, 10);
  const clientName = (oldRow.clients || [])[0]?.name || '';
  const f = oldRow.fields || {};

  const parts = [];
  if (changeFlags.engineerChanged) parts.push('изменён инженер');
  if (changeFlags.datesChanged) parts.push('изменены даты работ');
  const reason = 'Обновление по заявке (из планировщика): ' + parts.join(', ');

  const sDate = new Date(start), eDate = new Date(end);
  const itemUrl = `https://crm.prolabsupport.kz/crm/type/1058/details/${bitrixItemId}/`;
  const dealUrl = mgr?.dealId ? `https://crm.prolabsupport.kz/crm/deal/details/${mgr.dealId}/` : null;

  await notifyJobAssigned({
    engineerId, managerId, itemId: bitrixItemId, title: item.title || '', reason,
    svcLabel: f.df3 || '', engineerName,
    assignDate: fmtDateOnly(new Date()),
    startDate: fmtDateOnly(sDate), endDate: fmtDateOnly(eDate),
    clientName, contractLabel, managerName, instrLabel: f.df4 || '', location: '',
    url: itemUrl, dealUrl,
  });
}

router.put('/events/:id', requireAuth(), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { resource, title, type, start, end, allDay, confirmed, note, fields, clients, coAssignees } = req.body;
  if (!resource || !start || !end) return res.status(400).json({ error: 'resource, start, end are required' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: existingRows } = await client.query(
      `SELECT group_id, bitrix_item_id, resource, fields, clients,
        to_char(start_at AT TIME ZONE '${TZ}', 'YYYY-MM-DD') AS start_date_old,
        to_char(end_at AT TIME ZONE '${TZ}', 'YYYY-MM-DD') AS end_date_old
       FROM ticketsmodule_planner_events WHERE id=$1`, [id]
    );
    if (!existingRows.length) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Not found' }); }
    const groupId = existingRows[0].group_id || id;
    const bitrixItemId = existingRows[0].bitrix_item_id;
    const oldRow = existingRows[0];

    // Role gate: enforce against the EXISTING event's owner (engineer may only
    // edit their own; viewer none; management any).
    const ownerObj = { engineer: oldRow.resource, assignedById: await resolveBitrixUserId(oldRow.resource) };
    if (!canEdit(req.user, ownerObj)) { await client.query('ROLLBACK'); return res.status(403).json({ error: 'Недостаточно прав' }); }

    await client.query(
      `UPDATE ticketsmodule_planner_events
       SET resource=$1, title=$2, type=$3,
           start_at=$4::timestamp AT TIME ZONE '${TZ}', end_at=$5::timestamp AT TIME ZONE '${TZ}',
           all_day=$6, confirmed=$7, note=$8, fields=$9, clients=$10, group_id=$11, updated_at=NOW()
       WHERE id=$12`,
      [resource, title || '', type, start, end, !!allDay, !!confirmed, note || '',
       JSON.stringify(fields || {}), JSON.stringify(clients || []), groupId, id]
    );

    const { rows: siblings } = await client.query(
      'SELECT id, resource FROM ticketsmodule_planner_events WHERE group_id=$1 AND id<>$2', [groupId, id]
    );
    const keep = new Set(coAssignees || []);
    const ids = [id];

    for (const sib of siblings) {
      if (keep.has(sib.resource)) {
        keep.delete(sib.resource);
        await client.query(
          `UPDATE ticketsmodule_planner_events
           SET title=$1, type=$2, start_at=$3::timestamp AT TIME ZONE '${TZ}', end_at=$4::timestamp AT TIME ZONE '${TZ}',
               all_day=$5, confirmed=$6, note=$7, fields=$8, clients=$9, updated_at=NOW()
           WHERE id=$10`,
          [title || '', type, start, end, !!allDay, !!confirmed, note || '',
           JSON.stringify(fields || {}), JSON.stringify(clients || []), sib.id]
        );
        ids.push(sib.id);
      } else {
        await client.query('DELETE FROM ticketsmodule_planner_events WHERE id=$1', [sib.id]);
      }
    }
    for (const name of keep) {
      if (!name || name === resource) continue;
      const sib = await insertOne(client, { title, type, start, end, allDay, confirmed, note, fields, clients, resource: name, createdBy: req.user?.username });
      await client.query('UPDATE ticketsmodule_planner_events SET group_id=$1 WHERE id=$2', [groupId, sib.id]);
      ids.push(sib.id);
    }

    const result = await fetchByIds(client, ids);
    await client.query('COMMIT');
    if (bitrixItemId) {
      pushEventToBitrix(bitrixItemId, resource, start, end).catch(()=>{});
      const engineerChanged = oldRow.resource !== resource;
      const datesChanged = oldRow.start_date_old !== start.slice(0,10) || oldRow.end_date_old !== end.slice(0,10);
      if (engineerChanged || datesChanged) {
        notifyOutboundChange(bitrixItemId, resource, start, end, oldRow, { engineerChanged, datesChanged }).catch(e=>console.error('notifyOutboundChange error:', e.message));
      }
    }
    res.json({ events: result.map(rowToEvent) });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('PUT /api/planner/events/:id error:', e.message);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// ── DELETE /api/planner/events/:id — removes just this one instance ───────
router.delete('/events/:id', requireAuth(), async (req, res) => {
  // Deleting in Планировщик is limited to admin and coordinator (this is the
  // coordinator's module). Every delete is written to the audit log.
  if (!canDelete(req.user, 'PLN')) return res.status(403).json({ error: 'Недостаточно прав' });
  try {
    const { rows } = await pool.query('SELECT bitrix_item_id FROM ticketsmodule_planner_events WHERE id=$1', [req.params.id]);
    await pool.query('DELETE FROM ticketsmodule_planner_events WHERE id=$1', [req.params.id]);
    if (rows[0]?.bitrix_item_id) markRecentlyDeleted(rows[0].bitrix_item_id);
    const ip = req.headers['x-forwarded-for'] || req.ip;
    const ua = req.headers['user-agent'];
    auditLog(req.user.id, req.user.username, 'PLANNER_EVENT_DELETED', String(req.params.id),
      { bitrixItemId: rows[0]?.bitrix_item_id || null }, ip, ua).catch(()=>{});
    res.json({ ok: true });
  } catch (e) {
    console.error('DELETE /api/planner/events/:id error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// Planner configuration (data fields, config blobs, staff sync) is restricted
// to admin and coordinator — this is the coordinator's module.
function requirePlannerAdmin(req, res, next) {
  if (!['admin', 'coordinator'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Недостаточно прав' });
  }
  next();
}

// ── Custom Data Fields API (shared, replaces localStorage pls3_df) ────────
router.get('/datafields', requireAuth(), async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM ticketsmodule_planner_datafields ORDER BY sort_order, id');
    res.json({ dataFields: rows.map(r=>({id:r.id, name:r.name, type:r.type, options:r.options||[], required:r.required})) });
  } catch (e) {
    console.error('GET /api/planner/datafields error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/datafields', requireAuth(), requirePlannerAdmin, async (req, res) => {
  const { name, type, options } = req.body;
  if (!name || !type) return res.status(400).json({ error: 'name and type are required' });
  try {
    const { rows } = await pool.query(`SELECT id FROM ticketsmodule_planner_datafields WHERE id ~ '^df[0-9]+$'`);
    const maxN = rows.reduce((m,r)=>Math.max(m, parseInt(r.id.slice(2),10)||0), 9);
    const newId = 'df' + (maxN + 1);
    const { rows: maxSort } = await pool.query('SELECT COALESCE(MAX(sort_order),0) AS m FROM ticketsmodule_planner_datafields');
    await pool.query(
      'INSERT INTO ticketsmodule_planner_datafields (id, name, type, options, sort_order) VALUES ($1,$2,$3,$4,$5)',
      [newId, name, type, JSON.stringify(options || []), maxSort[0].m + 1]
    );
    res.json({ id: newId });
  } catch (e) {
    console.error('POST /api/planner/datafields error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/datafields/:id', requireAuth(), requirePlannerAdmin, async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  try {
    await pool.query('UPDATE ticketsmodule_planner_datafields SET name=$1 WHERE id=$2', [name, req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('PUT /api/planner/datafields/:id error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/datafields/:id', requireAuth(), requirePlannerAdmin, async (req, res) => {
  try {
    await pool.query('DELETE FROM ticketsmodule_planner_datafields WHERE id=$1', [req.params.id]);
    const ip = req.headers['x-forwarded-for'] || req.ip;
    const ua = req.headers['user-agent'];
    auditLog(req.user.id, req.user.username, 'PLANNER_DATAFIELD_DELETED', String(req.params.id),
      {}, ip, ua).catch(()=>{});
    res.json({ ok: true });
  } catch (e) {
    console.error('DELETE /api/planner/datafields/:id error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── Generic config blob API (staff roster, color palette) ─────────────────
router.get('/config/:key', requireAuth(), async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT value FROM ticketsmodule_planner_config WHERE key=$1', [req.params.key]);
    res.json({ value: rows[0]?.value ?? null });
  } catch (e) {
    console.error('GET /api/planner/config/:key error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});
router.put('/config/:key', requireAuth(), requirePlannerAdmin, async (req, res) => {
  try {
    await pool.query(
      `INSERT INTO ticketsmodule_planner_config (key, value, updated_at) VALUES ($1,$2,NOW())
       ON CONFLICT (key) DO UPDATE SET value=$2, updated_at=NOW()`,
      [req.params.key, JSON.stringify(req.body.value)]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error('PUT /api/planner/config/:key error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── Staff sync from Bitrix (one-directional: Bitrix → planner only) ───────
// Adds active Bitrix employees not yet in the roster; never removes or
// overwrites anything a person set up manually in the planner admin panel.
// Names/departments already in the roster are left completely alone.
const SERVICE_ACCOUNT_NAMES = new Set(['Администратор', 'Power BI']);
function normalizeName(name) { return (name || '').toLowerCase().replace(/\s+/g, ' ').trim(); }

async function fetchAllActiveUsers() {
  const users = [];
  let start = 0;
  while (true) {
    const { result, next } = await b24('user.get', { ACTIVE: true, start });
    if (!result || !result.length) break;
    users.push(...result);
    if (next === undefined) break;
    start = next;
  }
  return users;
}

async function syncStaffFromBitrix() {
  const FALLBACK_DEPT = 'Без отдела';
  const users = await fetchAllActiveUsers();
  let deptNameById = {};
  try {
    const { result: depts } = await b24('department.get', {});
    (depts || []).forEach(d => { deptNameById[d.ID] = d.NAME; });
  } catch (e) {
    console.warn('department.get failed (missing "company structure" scope on the webhook?) — falling back to "Без отдела" for everyone:', e.message);
  }

  const { rows } = await pool.query(`SELECT value FROM ticketsmodule_planner_config WHERE key='depts'`);
  const adminDepts = rows[0]?.value || [];

  const byNormName = new Map();
  adminDepts.forEach(d => d.members.forEach(m => byNormName.set(normalizeName(m.name), m)));
  const findDeptOf = (member) => adminDepts.find(d => d.members.includes(member));
  const findOrCreateDept = (name) => {
    let dept = adminDepts.find(d => normalizeName(d.name) === normalizeName(name));
    if (!dept) { dept = { id: 'dept_'+Date.now()+'_'+adminDepts.length, name, color: '#8a8784', members: [] }; adminDepts.push(dept); }
    return dept;
  };

  let added = 0, idBackfilled = 0, reassigned = 0;
  let nextStaffNum = Date.now() % 100000; // avoid collisions with existing 'staffN' ids

  for (const u of users) {
    const fullName = `${u.NAME || ''} ${u.LAST_NAME || ''}`.trim();
    if (!fullName || SERVICE_ACCOUNT_NAMES.has(fullName)) continue;
    const bitrixDeptId = (u.UF_DEPARTMENT || [])[0];
    const bitrixDeptName = deptNameById[bitrixDeptId] || FALLBACK_DEPT;

    const existing = byNormName.get(normalizeName(fullName));
    if (existing) {
      if (!existing.bitrixUserId) { existing.bitrixUserId = parseInt(u.ID, 10); idBackfilled++; }
      // Only reassign when we actually resolved a real department name —
      // never blindly move someone into the fallback bucket just because
      // department.get failed or this person's dept lookup came up empty.
      if (bitrixDeptName !== FALLBACK_DEPT) {
        const currentDept = findDeptOf(existing);
        if (currentDept && normalizeName(currentDept.name) !== normalizeName(bitrixDeptName)) {
          currentDept.members = currentDept.members.filter(m => m !== existing);
          findOrCreateDept(bitrixDeptName).members.push(existing);
          reassigned++;
        }
      }
      continue;
    }

    const dept = findOrCreateDept(bitrixDeptName);
    const newMember = {
      id: 'staff'+(nextStaffNum++), name: fullName, bitrixUserId: parseInt(u.ID, 10),
      role: 'member', perms: { view: true, edit: false, admin: false },
    };
    dept.members.push(newMember);
    byNormName.set(normalizeName(fullName), newMember);
    added++;
  }

  // Clean up any department left empty by the reassignment above
  for (let i = adminDepts.length - 1; i >= 0; i--) {
    if (adminDepts[i].members.length === 0) adminDepts.splice(i, 1);
  }

  await pool.query(
    `INSERT INTO ticketsmodule_planner_config (key, value, updated_at) VALUES ('depts',$1,NOW())
     ON CONFLICT (key) DO UPDATE SET value=$1, updated_at=NOW()`,
    [JSON.stringify(adminDepts)]
  );
  return { added, idBackfilled, reassigned, totalBitrixUsers: users.length };
}

router.post('/sync-staff', requireAuth(), requirePlannerAdmin, async (req, res) => {
  try {
    const result = await syncStaffFromBitrix();
    res.json({ ok: true, ...result });
  } catch (e) {
    console.error('POST /api/planner/sync-staff error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── Personal per-user preferences (e.g. which departments this person hides) ─
router.get('/my-prefs/:key', requireAuth(), async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT value FROM ticketsmodule_user_prefs WHERE user_id=$1 AND key=$2', [req.user.id, req.params.key]
    );
    res.json({ value: rows[0]?.value ?? null });
  } catch (e) {
    console.error('GET /api/planner/my-prefs/:key error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});
router.put('/my-prefs/:key', requireAuth(), async (req, res) => {
  try {
    await pool.query(
      `INSERT INTO ticketsmodule_user_prefs (user_id, key, value, updated_at) VALUES ($1,$2,$3,NOW())
       ON CONFLICT (user_id, key) DO UPDATE SET value=$3, updated_at=NOW()`,
      [req.user.id, req.params.key, JSON.stringify(req.body.value)]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error('PUT /api/planner/my-prefs/:key error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/planner/notifications/:bitrixItemId — notification history for one Bitrix item, shown in the event's "Уведомления" tab
router.get('/notifications/:bitrixItemId', requireAuth(), async (req, res) => {
  try {
    const itemId = parseInt(req.params.bitrixItemId, 10);
    if (!itemId) return res.status(400).json({ error: 'Неверный ID' });
    const { rows } = await pool.query(
      `SELECT sent_at, reason, channel, recipient_label, success, error
       FROM ticketsmodule_notification_log WHERE bitrix_item_id=$1 ORDER BY sent_at DESC`,
      [itemId]
    );
    res.json({ logs: rows });
  } catch (e) {
    console.error('GET /api/planner/notifications/:bitrixItemId error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = { router, rowToEvent, SELECT_COLS, TZ, syncStaffFromBitrix, fetchAllActiveUsers, computeSyncHash, resolveBitrixUserId };

