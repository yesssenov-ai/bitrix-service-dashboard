const express = require('express');
const router = express.Router();
const { requireAuth } = require('../auth');

// Определяем Bitrix-ID автора действия: сначала явная связка (bitrix_user_id из
// карточки пользователя), иначе — по совпадению имени учётки с сотрудником Bitrix.
// Если ничего не нашли — вернём null (тогда автором станет владелец вебхука).
function resolveBitrixId(user) {
  if (!user) return null;
  if (user.bitrix_user_id) return parseInt(user.bitrix_user_id, 10);
  const nm = user.engineer_name || user.display_name;
  if (nm) {
    try {
      const { USERS } = require('../constants');
      const found = Object.entries(USERS).find(([, n]) => n === nm);
      if (found) return parseInt(found[0], 10);
    } catch (e) { /* ignore */ }
  }
  return null;
}

// Модуль «План продаж» доступен по гранту модуля (страница закрыта requireModule),
// а API — любому авторизованному с доступом; ограничим ролями просмотра аналитики.
// engineer (менеджеры продаж) тоже видят план и могут редактировать СВОИ сделки —
// редактирование ограничено canCommentDeal (свои + свой отдел), просмотр общий.
const VIEW_ROLES = ['admin', 'coordinator', 'manager', 'engineer', 'store', 'accountant'];

// GET /api/plansales — обогащённый список доконтрактных сделок с планируемой датой.
router.get('/', requireAuth(VIEW_ROLES), async (req, res) => {
  try {
    const { getPlanSales } = require('../plansales-calc');
    const { canCommentDeal, EMPLOYEE_DEPT } = require('../dept-map');
    const data = await getPlanSales();
    // Права на комментарии: помечаем каждую сделку — может ли текущий пользователь
    // её комментировать (свои + своего отдела; админ — любые). Фронт по этому флагу
    // прячет поле ввода, сервер всё равно проверяет на POST.
    const bid = resolveBitrixId(req.user);
    (data.deals || []).forEach(d => { d.canComment = canCommentDeal(req.user, d.managerId, bid); });
    data.meta = data.meta || {};
    data.meta.me = { bid: bid || null, isAdmin: !!(req.user && req.user.role === 'admin'), dept: bid ? (EMPLOYEE_DEPT[bid] || null) : null };
    res.set('Cache-Control', 'no-store');
    res.json(data);
  } catch (e) {
    console.error('GET /api/plansales error:', e.message);
    res.status(500).json({ error: e.message, deals: [], meta: {} });
  }
});

// GET /api/plansales/version — дешёвый маркер изменений для поллинга (фронт тянет
// полный список только когда он изменился — экономит egress из Supabase).
router.get('/version', requireAuth(VIEW_ROLES), async (req, res) => {
  try {
    const { tableVersion } = require('../db-version');
    res.set('Cache-Control', 'no-store');
    res.json({ v: await tableVersion('ticketsmodule_stat_deals') });
  } catch (e) {
    console.error('GET /api/plansales/version error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// POST /api/plansales/refresh — быстрая инкрементальная синхронизация (как в
// Контрактах): тянет из Bitrix только сделки, изменённые с последней синхронизации.
let _refreshing = false;
router.post('/refresh', requireAuth(VIEW_ROLES), express.json(), async (req, res) => {
  if (_refreshing) return res.json({ ok: true, running: true, note: 'Обновление уже идёт' });
  _refreshing = true;
  try {
    const { pool } = require('../auth');
    const { rows } = await pool.query('SELECT MAX(synced_at) AS t FROM ticketsmodule_stat_deals');
    const last = rows[0] && rows[0].t ? new Date(rows[0].t).getTime() : null;
    const sinceMs = (last || (Date.now() - 7 * 86400 * 1000)) - 15 * 60 * 1000; // буфер 15 мин
    const { incrementalSync } = require('../stats-sync');
    const r = await incrementalSync(sinceMs);
    const { rows: r2 } = await pool.query('SELECT MAX(synced_at) AS t FROM ticketsmodule_stat_deals');
    res.json({ ok: true, updated: r.updated || 0, updatedAt: r2[0] && r2[0].t ? new Date(r2[0].t).toISOString() : null });
  } catch (e) {
    console.error('POST /api/plansales/refresh error:', e.message);
    res.status(500).json({ error: 'Не удалось обновить: ' + e.message });
  } finally { _refreshing = false; }
});

// GET /api/plansales/:id/comments — лента комментариев сделки из Bitrix (таймлайн).
router.get('/:id/comments', requireAuth(VIEW_ROLES), async (req, res) => {
  try {
    const { b24 } = require('../bitrix');
    const { USERS } = require('../constants');
    const id = parseInt(req.params.id, 10);
    const { result } = await b24('crm.timeline.comment.list', {
      filter: { ENTITY_ID: id, ENTITY_TYPE: 'deal' }, order: { CREATED: 'DESC' },
    });
    const items = (result || []).map(c => ({
      id: c.ID,
      text: c.COMMENT || '',
      authorId: c.AUTHOR_ID || null,
      author: c.AUTHOR_ID ? (USERS[c.AUTHOR_ID] || ('#' + c.AUTHOR_ID)) : '—',
      created: c.CREATED || null,
    }));
    res.set('Cache-Control', 'no-store');
    res.json({ ok: true, items });
  } catch (e) {
    console.error('GET /api/plansales/:id/comments error:', e.message);
    res.status(500).json({ error: e.message, items: [] });
  }
});

// POST /api/plansales/:id/comments { text } — добавить комментарий в сделку (в Bitrix).
router.post('/:id/comments', requireAuth(VIEW_ROLES), express.json(), async (req, res) => {
  try {
    const { b24 } = require('../bitrix');
    const id = parseInt(req.params.id, 10);
    const text = String((req.body || {}).text || '').trim();
    if (!text) return res.status(400).json({ error: 'Пустой комментарий' });
    const bid = resolveBitrixId(req.user);
    // Проверка прав: комментировать можно только свои сделки и сделки своего отдела
    // (админ — любые). Менеджера сделки берём из зеркала.
    const { canCommentDeal } = require('../dept-map');
    const { pool } = require('../auth');
    let dealMgr = null;
    try { const { rows } = await pool.query('SELECT assigned_by_id FROM ticketsmodule_stat_deals WHERE deal_id=$1', [id]); dealMgr = rows[0] ? rows[0].assigned_by_id : null; } catch (e) { /* ignore */ }
    if (!canCommentDeal(req.user, dealMgr, bid)) {
      return res.status(403).json({ error: 'Комментировать можно только свои сделки и сделки своего отдела.' });
    }
    const fields = { ENTITY_ID: id, ENTITY_TYPE: 'deal' };
    if (bid) {
      fields.AUTHOR_ID = bid;            // автор = текущий пользователь (по связке/имени)
      fields.COMMENT = text;
    } else {
      // Учётка не связана с Bitrix и имя не совпало — иначе автором стал бы
      // владелец вебхука. Сохраняем настоящего автора в тексте комментария.
      const who = (req.user && (req.user.display_name || req.user.engineer_name)) || 'сотрудник ЦУП';
      fields.COMMENT = `[${who}]: ${text}`;
    }
    const { result } = await b24('crm.timeline.comment.add', { fields });
    res.json({ ok: true, id: result, linked: !!bid });
  } catch (e) {
    console.error('POST /api/plansales/:id/comments error:', e.message);
    res.status(500).json({ error: 'Не удалось сохранить комментарий: ' + e.message });
  }
});

// POST /api/plansales/:id/task { title, description, deadline, responsibleId } —
// поставить задачу менеджеру по сделке (создаётся в Bitrix, привязана к сделке).
router.post('/:id/task', requireAuth(VIEW_ROLES), express.json(), async (req, res) => {
  try {
    const { b24 } = require('../bitrix');
    const id = parseInt(req.params.id, 10);
    const b = req.body || {};
    const title = String(b.title || '').trim();
    if (!title) return res.status(400).json({ error: 'Укажите название задачи' });
    const fields = { TITLE: title, DESCRIPTION: String(b.description || ''), UF_CRM_TASK: ['D_' + id] };
    if (b.responsibleId) fields.RESPONSIBLE_ID = parseInt(b.responsibleId, 10);
    if (b.deadline) fields.DEADLINE = /^\d{4}-\d{2}-\d{2}$/.test(b.deadline) ? (b.deadline + 'T18:00:00') : b.deadline;
    const cby = resolveBitrixId(req.user);
    if (cby) fields.CREATED_BY = cby;
    const { result } = await b24('tasks.task.add', { fields });
    const taskId = result && result.task && (result.task.id || result.task.ID);
    res.json({ ok: true, id: taskId });
  } catch (e) {
    console.error('POST /api/plansales/:id/task error:', e.message);
    res.status(500).json({ error: 'Не удалось создать задачу: ' + e.message });
  }
});

// POST /api/plansales/:id/likely { value } — отметить/снять «Наиболее вероятная»
// прямо из модуля. Пишем в поле сделки Bitrix и сразу обновляем локальное зеркало
// (чтобы флаг отразился мгновенно, не дожидаясь синхронизации). Права — как у
// комментариев: свои сделки и сделки своего отдела (админ — любые).
const LIKELY_DEAL_FIELD = process.env.PLAN_LIKELY_FIELD || 'UF_CRM_1752737840347';
router.post('/:id/likely', requireAuth(VIEW_ROLES), express.json(), async (req, res) => {
  try {
    const { b24 } = require('../bitrix');
    const { pool } = require('../auth');
    const { canCommentDeal } = require('../dept-map');
    const id = parseInt(req.params.id, 10);
    const value = !!(req.body || {}).value;
    const bid = resolveBitrixId(req.user);
    let dealMgr = null;
    try { const { rows } = await pool.query('SELECT assigned_by_id FROM ticketsmodule_stat_deals WHERE deal_id=$1', [id]); dealMgr = rows[0] ? rows[0].assigned_by_id : null; } catch (e) { /* ignore */ }
    if (!canCommentDeal(req.user, dealMgr, bid)) {
      return res.status(403).json({ error: 'Отмечать «наиболее вероятной» можно только свои сделки и сделки своего отдела.' });
    }
    await b24('crm.deal.update', { id, fields: { [LIKELY_DEAL_FIELD]: value ? 1 : 0 } });
    try { await pool.query('UPDATE ticketsmodule_stat_deals SET likely_deal=$1 WHERE deal_id=$2', [value, id]); } catch (e) { /* зеркало обновит и синк */ }
    res.json({ ok: true, value });
  } catch (e) {
    console.error('POST /api/plansales/:id/likely error:', e.message);
    res.status(500).json({ error: 'Не удалось изменить признак: ' + e.message });
  }
});

// POST /api/plansales/resync — полная пересинхронизация зеркала сделок (админ).
// Нужна разово после релиза, чтобы у существующих сделок заполнились новые поля
// (планируемый срок покупки, «наиболее вероятная»). Запускается в фоне.
let _resyncBusy = false;
router.post('/resync', requireAuth(['admin']), async (req, res) => {
  if (_resyncBusy) return res.json({ ok: true, started: false, busy: true });
  _resyncBusy = true;
  res.json({ ok: true, started: true });
  (async () => {
    try {
      const { fullSync } = require('../stats-sync');
      await fullSync();
    } catch (e) { console.error('plansales resync error:', e.message); }
    finally { _resyncBusy = false; }
  })();
});

module.exports = { router };
